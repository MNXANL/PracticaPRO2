var searchData=
[
  ['seccio',['seccio',['../class_producte.html#a445f0b7691a31504e2dd48e3406347a3',1,'Producte']]],
  ['sumtemps',['sumTemps',['../class_caixa.html#a36e1554f9733b82d9dd85ec97347c9e4',1,'Caixa']]]
];
