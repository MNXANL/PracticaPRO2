var searchData=
[
  ['permute',['permute',['../class_super.html#a177b1143c8b3eb923386245b9b12f039',1,'Super']]],
  ['posicio_5fque_5ftoca',['Posicio_Que_Toca',['../class_super.html#a2836f8ad6036983cfb0c31a7e89a7bce',1,'Super']]],
  ['producte',['Producte',['../class_producte.html#aa3df33bb7528537f4eefbb92e7e4c2f3',1,'Producte']]]
];
