var searchData=
[
  ['wait',['wait',['../class_caixa.html#a9f92223d0a42675384bc02bacbd0b2e9',1,'Caixa']]]
];
