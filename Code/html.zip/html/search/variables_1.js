var searchData=
[
  ['es_5frapid',['es_rapid',['../class_caixa.html#a51a2f53f0ed12b639b1c872d0ed9b9d2',1,'Caixa']]]
];
