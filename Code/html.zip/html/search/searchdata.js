var indexSectionsWithContent =
{
  0: "acdeilmnprstuvw",
  1: "cps",
  2: "cps",
  3: "acdeilmnps",
  4: "celmnprstuvw",
  5: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Pàgines"
};

