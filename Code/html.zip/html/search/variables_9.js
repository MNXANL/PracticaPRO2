var searchData=
[
  ['unitats',['unitats',['../class_client.html#afe74a3a8cf64a5f32fb1e6960abab284',1,'Client']]]
];
