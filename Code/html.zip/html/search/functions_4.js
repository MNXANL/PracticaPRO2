var searchData=
[
  ['inicialitzar',['Inicialitzar',['../class_super.html#a2ef589f86c3896de0b0799133603f4f5',1,'Super']]]
];
