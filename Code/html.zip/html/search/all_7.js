var searchData=
[
  ['null_5fcua',['Null_Cua',['../class_caixa.html#a13984859b8716621d87e7dfb7f1e65a5',1,'Caixa']]],
  ['num_5fproducte',['num_producte',['../class_super.html#a83ddd735c6501502027bec764b827b68',1,'Super']]]
];
