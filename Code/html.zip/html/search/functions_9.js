var searchData=
[
  ['settovector',['settovector',['../class_super.html#a9f59e8f38a04569e7cbd970c7144eafa',1,'Super']]],
  ['sim_5fpagament',['Sim_Pagament',['../class_super.html#a3a2bba4bf3509b7ceda992cde4bc1cb6',1,'Super']]],
  ['suma_5ftemps',['Suma_Temps',['../class_super.html#a082b1df70d3a5570f83d93524c8e3d17',1,'Super']]],
  ['sumar_5felement_5fcua',['Sumar_Element_Cua',['../class_caixa.html#aeae2b0438e82230650ff664ae1a2fa0b',1,'Caixa']]],
  ['super',['Super',['../class_super.html#aaf532eb5ecc434595c537e5b0a61932f',1,'Super']]]
];
