var searchData=
[
  ['llegir_5fclient',['Llegir_Client',['../class_client.html#aae8cb3f203ce5d5efb95263052e22b64',1,'Client']]],
  ['llegir_5fproducte',['Llegir_Producte',['../class_producte.html#ac002b950b21dcbfe3966b650c9c2b46c',1,'Producte']]],
  ['llegir_5fproductes_5fclient',['Llegir_Productes_Client',['../class_client.html#add17d1ecd01590279d560e2904833e8e',1,'Client']]]
];
