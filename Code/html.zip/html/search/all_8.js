var searchData=
[
  ['permute',['permute',['../class_super.html#a177b1143c8b3eb923386245b9b12f039',1,'Super']]],
  ['posicio_5fque_5ftoca',['Posicio_Que_Toca',['../class_super.html#a2836f8ad6036983cfb0c31a7e89a7bce',1,'Super']]],
  ['preu',['preu',['../class_producte.html#a87ccbe2a716ef282f57491627d9b779f',1,'Producte']]],
  ['producte',['Producte',['../class_producte.html',1,'Producte'],['../class_producte.html#aa3df33bb7528537f4eefbb92e7e4c2f3',1,'Producte::Producte()']]],
  ['producte_2ehh',['Producte.hh',['../_producte_8hh.html',1,'']]],
  ['producte_5fid',['producte_id',['../class_producte.html#acd3c8798461746b265994e615c15c5f3',1,'Producte']]],
  ['productes',['Productes',['../class_super.html#a3a87e997e6dc8a82731ca632e8293ffd',1,'Super']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
