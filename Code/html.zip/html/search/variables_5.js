var searchData=
[
  ['preu',['preu',['../class_producte.html#a87ccbe2a716ef282f57491627d9b779f',1,'Producte']]],
  ['producte_5fid',['producte_id',['../class_producte.html#acd3c8798461746b265994e615c15c5f3',1,'Producte']]],
  ['productes',['Productes',['../class_super.html#a3a87e997e6dc8a82731ca632e8293ffd',1,'Super']]]
];
