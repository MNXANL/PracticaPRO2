var searchData=
[
  ['num_5fproducte',['num_producte',['../class_super.html#a83ddd735c6501502027bec764b827b68',1,'Super']]]
];
