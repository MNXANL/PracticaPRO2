var searchData=
[
  ['mida',['mida',['../class_client.html#af9b3e3c5788f38acdfe630c701e316a7',1,'Client']]],
  ['midacami',['MidaCami',['../class_super.html#ad1fd58c7cc808a45e37986d2fabc94ce',1,'Super']]]
];
