var searchData=
[
  ['caixes',['caixes',['../class_super.html#a7682927361a5750ef8b2de2924fa904c',1,'Super::caixes()'],['../class_super.html#accb44a2bd108b0a57afb22e483cd7656',1,'Super::Caixes()']]],
  ['cola',['cola',['../class_caixa.html#a89cd1a3415be2b9acee9a4ad9fb07287',1,'Caixa']]],
  ['columnes',['columnes',['../class_super.html#acac9141598511a2dbccb648927e51ed1',1,'Super']]],
  ['compr_5fid',['compr_id',['../class_client.html#a18ae682e88943b762bce87be255559e0',1,'Client']]]
];
