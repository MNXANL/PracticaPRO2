var searchData=
[
  ['lliure',['lliure',['../class_caixa.html#aaaecfa3936a38ff6ef5d73decb33dda2',1,'Caixa']]],
  ['lprod',['lprod',['../class_client.html#aeb212fdfbe2c7dda880126194101fed7',1,'Client']]]
];
