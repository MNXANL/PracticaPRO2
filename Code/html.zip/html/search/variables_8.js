var searchData=
[
  ['temps',['temps',['../class_producte.html#a084e16e1899d584d4f008a57f766ba61',1,'Producte']]],
  ['temps_5fde_5fpagar',['temps_de_pagar',['../class_client.html#ab54969f3c335f560c3b926c7ad197120',1,'Client']]],
  ['temps_5fticket',['temps_ticket',['../class_client.html#ace60a20e75fbec9d982cc2703412e191',1,'Client']]]
];
